DarwiinRemote OSC

0.3.1 2010/08/11
darwiinremoteOSC pre release compiled against latest darwiinremote version and compatible with 10.5 and 10.6. please give feedback if this version does not operate properly or behaves differently than the previous version. since it is a pre-release.

0.2.1 2008/01/14
darwiinremoteOSC is an osx application that interfaces with the bluetooth based wiiremote and the nunchuk controller. the original darwiinremote was written by Hiroaki Kimura, source available at sourceforge at http://sourceforge.net/projects/darwiin-remote/

this release of darwiinremoteOSC support the wiimote including IR support and full nunchuk support. any control data change is transmitted via OSC to a remote address. the address space is described in the attached addressSpace.txt file.
attached are 2 exmaples for the processing environment (http://www.processing.org/ and you will need the oscP5 library, download from http://www.sojamo.de/oscP5)
you can change the remote address and  the remote port in the preferences.
for questions, comments, and bug reports, please contact andreas schlegel at andi@sojamo.de

for copyright see the attached COPYRIGHT.txt



