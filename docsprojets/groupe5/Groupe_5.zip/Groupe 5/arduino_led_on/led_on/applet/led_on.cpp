/*
  Blink
 
 Turns on an LED on for one second, then off for one second, repeatedly.
 
 The circuit:
 * LED connected from digital pin 13 to ground.
 
 * Note: On most Arduino boards, there is already an LED on the board
 connected to pin 13, so you don't need any extra components for this example.
 
 
 Created 1 June 2005
 By David Cuartielles
 
 http://arduino.cc/en/Tutorial/Blink
 
 based on an orginal by H. Barragan for the Wiring i/o board
 
 */

#include "WProgram.h"
void setup();
void loop();
int ledPin =  2;
int ledPin2 = 3;
int ledPin3 = 4;
int ledPin4 = 5;
int ledPin5 = 6;
int ledPin6 = 7;
int ledPin7 = 8;
int ledPin8 = 9;
int ledPin9 = 10;
int ledPin10 = 11;
int ledPin11 = 12;
int ledPin12 = 13;




int info = 0;	// for incoming serial data
// The setup() method runs once, when the sketch starts

void setup()   {    
  Serial.begin(9600);	// opens serial port, sets data rate to 9600 bps    
  // initialize the digital pin as an output:
  pinMode(ledPin, OUTPUT);
  pinMode(ledPin2, OUTPUT);  
  pinMode(ledPin3, OUTPUT);
  pinMode(ledPin4, OUTPUT);
  pinMode(ledPin5, OUTPUT);  
  pinMode(ledPin6, OUTPUT);
  pinMode(ledPin7, OUTPUT);
  pinMode(ledPin8, OUTPUT);  
  pinMode(ledPin9, OUTPUT);
  pinMode(ledPin10, OUTPUT);
  pinMode(ledPin11, OUTPUT);  
  pinMode(ledPin12, OUTPUT);


}

// the loop() method runs over and over again,
// as long as the Arduino has power

void loop()                     
{
  if (Serial.available() > 0) {
    // read the incoming byte:
    info = Serial.read();
    if(info == 1){
      digitalWrite(ledPin, HIGH);

    }
    

    if(info == 2){
      digitalWrite(ledPin2, HIGH);

    }
    
    if(info == 3){
      digitalWrite(ledPin3, HIGH);

    }
    

    if(info == 4){
      digitalWrite(ledPin4, HIGH);

    }
    
    if(info == 5){
      digitalWrite(ledPin5, HIGH);

    }
    
    if(info == 6){
      digitalWrite(ledPin6, HIGH);

    }
    
    if(info == 7){
      digitalWrite(ledPin7, HIGH);

    }
    
    if(info == 8){
      digitalWrite(ledPin8, HIGH);

    }
    
    if(info == 9){
      digitalWrite(ledPin9, HIGH);

    }
    
    if(info == 10){
      digitalWrite(ledPin10, HIGH);

    }
    
    if(info == 11){
      digitalWrite(ledPin11, HIGH);

    }
    
    if(info == 12){
      digitalWrite(ledPin12, HIGH);

    }
    
    // say what you got:
    Serial.print("I received: ");
    Serial.println(info, DEC);
  }
  /*digitalWrite(ledPin, HIGH);   // set the LED on
   delay(1000);                  // wait for a second
   digitalWrite(ledPin, LOW);    // set the LED off
   delay(1000);*/  // wait for a second
}









int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

