package photoorganizer;
import java.io.*;

public class SimplePublisher implements Publisher {
    public String publish(java.util.Hashtable params) {
        StringBuffer result = new StringBuffer();
        try {
            String root = (String)params.get(photoorganizer.servlet.Uploader.WEB_ROOT);
            String name = (String)params.get("TargetName");
            if (name == null || name.length() == 0)
                name = new File((String)params.get("filename")).getName();
            else
                name = new File(name).getName();
            File of = new File(root, name);
            if (of.getParent() != null) {
                File pof = new File(of.getParent());
                // check for directories 
                if (! pof.exists())
                   pof.mkdirs();
            }
            FileOutputStream fos = new FileOutputStream(of);
            Object data = params.get("UploadData");
            if(data instanceof byte[])
                fos.write((byte[])data);
            else if(data instanceof String)
                fos.write(((String)data).getBytes());
            fos.close();
            result.append("Data from ").append(params.get("filename")).append(" have been written to ").append(name);
        } catch(Exception e) {
            result.append("Exception ").append(e.toString());
            e.printStackTrace();
        }
        return result.toString();
    }
}