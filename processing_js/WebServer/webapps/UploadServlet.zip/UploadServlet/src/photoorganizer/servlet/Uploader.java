/* PhotoOrganizer - servlet for image uploading
 * Copyright (C) 1999-2000 Dmitry Rogatkin.  All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 *  ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package photoorganizer.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.net.*;

import photoorganizer.Publisher;

public class Uploader extends HttpServlet {
    static final String PUBLISHERS = "publishers";
    public static final String WEB_ROOT = "webroot";
    static final String MULTIPARTDATA = "multipart/form-data"; 
    static final String BOUNDARY_ATTR = "boundary=";
    static final String NAME = "Uploader";
    static final String END_SFX = "--";
    static final long DEF_MAX_LENGTH = 300*1024*1024; // 10MB
    long max_req_length;
    
    Publisher []publishers;
    String webRoot;

	// TODO: add possibility using temporary file, if uploaded data bigger
	// than specified size and push to hashtable name of temporary file
	public void init(ServletConfig config) 
        throws ServletException {
		       
        super.init(config);
		
        max_req_length = DEF_MAX_LENGTH;
        String s = config.getInitParameter(PUBLISHERS);
        publishers = new Publisher[0];
        if (s != null) {
            StringTokenizer pt = new StringTokenizer(s, ";");
            while(pt.hasMoreTokens()) {
                try {
                    Class pc = Class.forName(pt.nextToken());
                    Publisher p = (Publisher)pc.newInstance();
                    // TODO: find a constructor in publisher that gets ServletConfig as a parameter, if any
                    Publisher []tp = new Publisher [publishers.length+1];
                    System.arraycopy(publishers, 0, tp, 0, publishers.length);
                    tp[publishers.length] = p;
                    publishers = tp;
                } catch(Throwable e) {
                }
            }
        }
        webRoot = config.getInitParameter(WEB_ROOT);
        if (webRoot == null) {
              System.err.println("Web root is null, ./ assumed");
              webRoot = "./";
        } else
			System.err.println("Web root from init "+webRoot);
	}

    public void doGet (HttpServletRequest request, 
                       HttpServletResponse response) 
        throws ServletException, IOException
    {
        response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED, NAME+": doesn't support GET request");
    }

    public void doPost (HttpServletRequest request, 
                        HttpServletResponse response) 
        throws ServletException, IOException
    {
        String encoding = request.getContentType();
        if (encoding.indexOf(MULTIPARTDATA) < 0) {
            response.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED, NAME+": supports only "+MULTIPARTDATA);
            return;
        }
        ServletInputStream sis = (ServletInputStream)request.getInputStream();
        String contentType = request.getContentType();
        int bp = -1;
        if (contentType == null || (bp = contentType.indexOf(BOUNDARY_ATTR)) < 0) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, NAME+": boundary must be specified for such request");
            return;
        }
        String boundary = contentType.substring(bp+BOUNDARY_ATTR.length()); // it can be not last attribute
        int boundaryLength = boundary.length();
        int contentLength = request.getContentLength();
        if (contentLength < 0) {
            response.sendError(HttpServletResponse.SC_LENGTH_REQUIRED, NAME+": invalid content length "+contentLength);
            return; // nothing to do, no data
        }
        if (contentLength == 0) {
            response.sendError(HttpServletResponse.SC_LENGTH_REQUIRED, NAME+": content length is 0");
			return;
        }
        if (contentLength > max_req_length) {
            response.sendError(HttpServletResponse.SC_REQUEST_ENTITY_TOO_LARGE, NAME+": can't proceed so big data");
			return;
        }
        byte[] buffer = new byte[contentLength];
        int contentRead = 0;
        UploadRequest uploadRequest = new UploadRequest();
main_loop: do {
               if (contentRead > contentLength) {
                   response.sendError(HttpServletResponse.SC_BAD_REQUEST, NAME+": Bad Request, data after content length");
                   return;
               }
               // read --------------boundary
               int ec = sis.readLine(buffer, contentRead, contentLength-contentRead);
               if (ec < 0) {
                   response.sendError(HttpServletResponse.SC_BAD_REQUEST, NAME+": Bad Request, data expected");
                   return;
               }
               String s = new String(buffer, 0, contentRead, ec);
               contentRead += ec;
               int p = s.indexOf(boundary);
               if (p >= 0) {
                   if (s.regionMatches(p+boundaryLength, END_SFX, 0, END_SFX.length()))
                       break; // it shouldn't happen here, but it's Ok
                   // skip the bounder, if it happens, because it's first
                   ec = sis.readLine(buffer, contentRead, contentLength-contentRead);
                   s = new String(buffer, 0, contentRead, ec);
                   contentRead += ec;
               }
               // s contains here first line of a part
               int dp, ep;
               String header, name=null, filename=null, token, contentype=null;
               do {
                   dp = s.indexOf(':');
                   if (dp < 0) {
                       response.sendError(HttpServletResponse.SC_BAD_REQUEST, NAME+": Bad Request, no header name delimiter");
                       return;
                   }
                   header = s.substring(0, dp);
                   s = s.substring(dp+2);
                   if ("Content-Disposition".equals(header)) {
                       StringTokenizer ast = new StringTokenizer(s, ";");
                       if (ast.hasMoreTokens()) {
                           token = ast.nextToken();
                           if (token.indexOf("form-data")< 0) {
                               response.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED, NAME+": Not Implemented - "+s);
                               return;
                           }
                           while (ast.hasMoreTokens()) {
                               token = ast.nextToken();
                               dp = token.indexOf("filename=\"");
                               if (dp >= 0) {
                                   ep = token.indexOf('"', dp+10);
                                   if (ep < 0 || ep == dp+10) {
                                       response.sendError(HttpServletResponse.SC_BAD_REQUEST, NAME+": Bad Request, no ending '\"' for filename attribute value");
                                       return;
                                   }
                                   if (filename != null) {
                                       response.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED, NAME+": Not Implemented, more than 1 filename in the same part");
                                       return;
                                   }
                                   filename = token.substring(dp+10, ep);
                                   continue;
                               }
                               dp = token.indexOf("name=\"");
                               if (dp >=0 ) {
                                   ep = token.indexOf('"', dp+6);
                                   if (ep < 0 || ep == dp+6) {
                                       response.sendError(HttpServletResponse.SC_BAD_REQUEST, NAME+": Bad Request, no ending '\"' for name attribute value");
                                       return;
                                   }
                                   if (name != null) {
                                       response.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED, NAME+": Not Implemented, more than 1 filename in the same part");
                                       return;
                                   }
                                   name = token.substring(dp+6, ep);
                                   continue;
                               }
                           }
                       }
                       if (filename != null)
                           uploadRequest.put("filename", filename);
                   } else if ("Content-Type".equals(header)) {
                       contentype = s;
                   }
                   ec = sis.readLine(buffer, contentRead, contentLength-contentRead);
                   if (ec < 0) {
                       response.sendError(HttpServletResponse.SC_BAD_REQUEST, NAME+": Bad Request, unexpected end of stream");
                       return;
                   }
                   if(ec == 2 && buffer[contentRead] == 0x0D && buffer[contentRead+1] == 0x0A) {
                       contentRead += ec;
                       break; // empty line read, skip it
                   }
                   s = new String(buffer, 0, contentRead, ec);

               } while(true);
               if (name == null) {
                   response.sendError(HttpServletResponse.SC_BAD_REQUEST, NAME+": Bad Request, no name attribute");
                   return;
               }
               int marker = contentRead;
               if (contentype == null || contentype.indexOf("text/") >= 0
                   || contentype.indexOf("application/") >= 0
                   || contentype.indexOf("unknown") >= 0) { // read everything
                   do {
                       ec = sis.readLine(buffer, contentRead, contentLength-contentRead);
                       if (ec < 0) {
                           response.sendError(HttpServletResponse.SC_BAD_REQUEST, NAME+": Bad Request, unexpected end of stream");
                           return;
                       }
                       s = new String(buffer, 0, contentRead, ec);
                       p = s.indexOf(boundary);
                       if (p >= 0) { // we met a bounder
                           // finish current part
                           if (contentRead-marker <= 2) {
                               // no file content in the stream, probably it's remote file
                               try {
                                   URLConnection uc = new URL(filename).openConnection();
                                   //contentype = ;
                                   if (uc.getContentType().indexOf("image/") >= 0) { // support only images for now
                                       int cl = uc.getContentLength();
                                       if (cl > 0 && cl < max_req_length) {// support only known sizes
                                           InputStream uis = uc.getInputStream();
                                           if (uis != null) {
                                               byte []im = new byte[cl];
                                               cl = 0;
                                               int rc;
                                               do {
                                                   rc = uis.read(im, cl, im.length-cl);
                                                   if (rc < 0)
                                                       break;
                                                   cl += rc;
                                               } while(rc > 0);
                                               uis.close();
                                               uploadRequest.put(name, im);
                                           }
                                       } else { // length unknown but we can try catch it
                                           InputStream uis = uc.getInputStream();
                                           if (uis != null) {
                                               byte []buf = new byte[2048];
                                               byte []im = new byte[0];
                                               try {
                                                   do {
                                                       cl = uis.read(buf);
                                                       if (cl < 0)
                                                           break;
                                                       byte []wa = new byte[im.length+cl];
                                                       System.arraycopy(im, 0, wa, 0, im.length);
                                                       System.arraycopy(buf, 0, wa, im.length, cl);
                                                       im = wa;
                                                   } while(true);
                                               } finally {
                                                   uis.close();
                                               }
                                               uploadRequest.put(name, im);
                                           }
                                       }
                                   }
                               } catch(MalformedURLException mfe) {
                               }
                           } else {
                               if(contentype != null && contentype.indexOf("application/") >= 0) {
                                   byte []im = new byte[contentRead-marker-2];
                                   System.arraycopy(buffer, marker, im, 0, contentRead-marker-2/*crlf*/);
                                   uploadRequest.put(name, im);
                               } else {
                                   uploadRequest.put(name, new String(buffer, 0, marker, contentRead-marker-2/*crlf*/));
                                   //System.err.println("put on "+name+"\n"+new String(buffer, 0, marker, contentRead-marker));
                               }
                           }
                           if (s.regionMatches(p+boundaryLength, END_SFX, 0, END_SFX.length()))
                               break main_loop; // it shouldn't happen here, but it's Ok
                           contentRead += ec;
                           break;
                       }
                       contentRead += ec;
                   } while(true);
               } else if (contentype.indexOf("image/") >= 0) {
                   do {
                       ec = sis.readLine(buffer, contentRead, contentLength-contentRead);
                       if (ec < 0) {
                           response.sendError(HttpServletResponse.SC_BAD_REQUEST, NAME+": Bad Request, unexpected end of stream");
                           return;
                       }
                       s = new String(buffer, 0, contentRead, ec);
                       p = s.indexOf(boundary);
                       if (p >= 0) { // we met a bounder
                           byte []im = new byte[contentRead-marker-2];
                           System.arraycopy(buffer, marker, im, 0, contentRead-marker-2);
                           uploadRequest.put(name, im);
                           if (s.regionMatches(p+boundaryLength, END_SFX, 0, END_SFX.length()))
                               break main_loop; // it shouldn't happen here, but it's Ok
                           contentRead += ec;
                           break;
                       }
                       contentRead += ec;
                   } while(true);
               } else {
                   response.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED, NAME+": Not Implemented, content type \""+contentype+'"');
                   return;
               }               
           } while(true);
           uploadRequest.put(WEB_ROOT, webRoot);
           response.setContentType("text/html");
           PrintWriter out = response.getWriter();
           out.println("<HTML><HEAD><TITLE>");
           out.println(NAME);
           out.println("</TITLE></HEAD><BODY>");
           out.println("<H1>Publishing results</H1>");
           out.println("<PRE>");
           for (int i=0; i<publishers.length; i++) {
               out.println(publishers[i].publish(uploadRequest));
           }
           out.println("</PRE>");
           out.println("</BODY></HTML>");
           out.close();
    }
    
    public void destroy() {
        System.err.println("Destroy");
    }
}

class UploadRequest extends Hashtable {
    public Object put(Object key, Object value) {
        Object result = get(key);
        if (result == null) {
            super.put(key, value);
        } else if (result instanceof Object[]) {
            Object[] na = new Object[((Object[])result).length+1];
            System.arraycopy((Object[])result, 0, na, 0, ((Object[])result).length);
            na[((Object[])result).length] = value;
            super.put(key, na);
        } else {
            Object[] na = new Object[2];
            na[0] = result;
            na[1] = value;
            super.put(key, na);
        }
        return result;
    }
}