#define LEFT_TRIGGER_PIN 2
#define LEFT_ECHO_PIN 3
#define RIGHT_TRIGGER_PIN 4
#define RIGHT_ECHO_PIN 5

#include "WProgram.h"
void setup();
void loop();
int left_pulse_length;
int right_pulse_length;

void setup()
{
  pinMode(LEFT_TRIGGER_PIN, OUTPUT);
  pinMode(LEFT_ECHO_PIN, INPUT);
  pinMode(RIGHT_TRIGGER_PIN, OUTPUT);
  pinMode(RIGHT_ECHO_PIN, INPUT);
  
  pinMode(6, INPUT);
  pinMode(7, INPUT);
  pinMode(8, INPUT);
  pinMode(9, INPUT);
  pinMode(10, INPUT);
  pinMode(11, INPUT);

  Serial.begin(9600);
}

void loop() {  
  // R\u00e9cup\u00e9ration distance gauche
  digitalWrite(LEFT_TRIGGER_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(LEFT_TRIGGER_PIN, LOW);
  left_pulse_length = int (pulseIn(LEFT_ECHO_PIN, HIGH));
  delay(50);
  
  // R\u00e9cup\u00e9ration distance droite
  digitalWrite(RIGHT_TRIGGER_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(RIGHT_TRIGGER_PIN, LOW);
  right_pulse_length = int (pulseIn(RIGHT_ECHO_PIN, HIGH));
  delay(50);
  
  // Envoi des donn\u00e9es
  Serial.print(left_pulse_length, DEC);
  Serial.print(",");
  Serial.print(right_pulse_length, DEC);
  Serial.print(",");
  Serial.print(digitalRead(6), DEC);
  Serial.print(",");
  Serial.print(digitalRead(7), DEC);
  Serial.print(",");
  Serial.print(digitalRead(8), DEC);
  Serial.print(",");
  Serial.print(digitalRead(9), DEC);
  Serial.print(",");
  Serial.print(digitalRead(10), DEC);
  Serial.print(",");
  Serial.println(digitalRead(11), DEC);
}

int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

